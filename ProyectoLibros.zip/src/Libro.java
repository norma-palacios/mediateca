package model;

public class Libro {
    private String codigoIdentificacion;
    private String titulo;
    private int numeroPaginas;
    private String editorial;
    private String isbn;
    private int anioPublicacion;
    private int unidadesDisponibles;
    private int idAutor;

    public Libro() {}

    public Libro(String codigoIdentificacion, String titulo, int numeroPaginas, String editorial, String isbn, int anioPublicacion, int unidadesDisponibles, int idAutor) {
        this.codigoIdentificacion = codigoIdentificacion;
        this.titulo = titulo;
        this.numeroPaginas = numeroPaginas;
        this.editorial = editorial;
        this.isbn = isbn;
        this.anioPublicacion = anioPublicacion;
        this.unidadesDisponibles = unidadesDisponibles;
        this.idAutor = idAutor;
    }
}
