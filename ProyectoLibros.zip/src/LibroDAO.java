package dao;

import model.Libro;
import java.sql.*;

public class LibroDAO {
    private final String url = "jdbc:mysql://localhost/mediateca";
    private final String usuario = "Gio20";
    private final String contraseña = "Manuel2005";

    public Connection conectar() throws SQLException {
        return DriverManager.getConnection(url, usuario, contraseña);
    }

    public void agregarLibro(Libro libro) {
        String sql = "INSERT INTO libro(titulo, numero_paginas, editorial, ISBN, anio_publicacion, unidades_disponibles, id_autor) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, libro.getTitulo());
            stmt.setInt(2, libro.getNumeroPaginas());
            stmt.setString(3, libro.getEditorial());
            stmt.setString(4, libro.getIsbn());
            stmt.setInt(5, libro.getAnioPublicacion());
            stmt.setInt(6, libro.getUnidadesDisponibles());
            stmt.setInt(7, libro.getIdAutor());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
