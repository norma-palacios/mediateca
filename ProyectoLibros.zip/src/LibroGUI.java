package view;

import dao.LibroDAO;
import model.Libro;
import javax.swing.*;
import java.awt.event.*;

public class LibroGUI extends JFrame {
    private JTextField tituloField;
    private JButton agregarButton;
    private LibroDAO libroDAO;

    public LibroGUI() {
        setTitle("Gestión de Libros");
        setLayout(null);
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        libroDAO = new LibroDAO();

        JLabel lblTitulo = new JLabel("Título:");
        lblTitulo.setBounds(20, 20, 100, 25);
        add(lblTitulo);

        tituloField = new JTextField();
        tituloField.setBounds(120, 20, 200, 25);
        add(tituloField);

        agregarButton = new JButton("Agregar Libro");
        agregarButton.setBounds(120, 70, 150, 30);
        agregarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Libro libro = new Libro();
                libro.setTitulo(tituloField.getText());
                libroDAO.agregarLibro(libro);
                JOptionPane.showMessageDialog(null, "Libro agregado correctamente!");
            }
        });
        add(agregarButton);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new LibroGUI().setVisible(true);
        });
    }
}
