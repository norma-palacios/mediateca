CREATE TABLE `libro` (
  `codigo_identificacion` varchar(10) NOT NULL DEFAULT '0',
  `titulo` varchar(100) NOT NULL,
  `numero_paginas` int(11) NOT NULL,
  `editorial` varchar(40) NOT NULL,
  `ISBN` varchar(30) NOT NULL,
  `anio_publicacion` int(11) NOT NULL,
  `unidades_disponibles` int(11) NOT NULL,
  `id_autor` int(11) NOT NULL,
  PRIMARY KEY (`codigo_identificacion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;