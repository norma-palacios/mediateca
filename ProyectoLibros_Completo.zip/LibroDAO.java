
package logica;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LibroDAO {
    private Connection conn;

    public LibroDAO(Connection conn) {
        this.conn = conn;
    }

    public void agregarLibro(Libro libro) throws SQLException {
        String sql = "INSERT INTO libro (titulo, numero_paginas, editorial, ISBN, anio_publicacion, unidades_disponibles, id_autor) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, libro.getTitulo());
            stmt.setInt(2, libro.getNumeroPaginas());
            stmt.setString(3, libro.getEditorial());
            stmt.setString(4, libro.getIsbn());
            stmt.setInt(5, libro.getAnioPublicacion());
            stmt.setInt(6, libro.getUnidadesDisponibles());
            stmt.setInt(7, libro.getIdAutor());
            stmt.executeUpdate();
        }
    }

    public List<Libro> listarLibros() throws SQLException {
        List<Libro> libros = new ArrayList<>();
        String sql = "SELECT * FROM libro";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                libros.add(new Libro(
                    rs.getString("codigo_identificacion"),
                    rs.getString("titulo"),
                    rs.getInt("numero_paginas"),
                    rs.getString("editorial"),
                    rs.getString("ISBN"),
                    rs.getInt("anio_publicacion"),
                    rs.getInt("unidades_disponibles"),
                    rs.getInt("id_autor")
                ));
            }
        }
        return libros;
    }

    public void eliminarLibro(String codigo) throws SQLException {
        String sql = "DELETE FROM libro WHERE codigo_identificacion = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, codigo);
            stmt.executeUpdate();
        }
    }

    public void editarLibro(Libro libro) throws SQLException {
        String sql = "UPDATE libro SET titulo=?, numero_paginas=?, editorial=?, ISBN=?, anio_publicacion=?, unidades_disponibles=?, id_autor=? WHERE codigo_identificacion=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, libro.getTitulo());
            stmt.setInt(2, libro.getNumeroPaginas());
            stmt.setString(3, libro.getEditorial());
            stmt.setString(4, libro.getIsbn());
            stmt.setInt(5, libro.getAnioPublicacion());
            stmt.setInt(6, libro.getUnidadesDisponibles());
            stmt.setInt(7, libro.getIdAutor());
            stmt.setString(8, libro.getCodigoIdentificacion());
            stmt.executeUpdate();
        }
    }

    public Libro buscarLibro(String codigo) throws SQLException {
        String sql = "SELECT * FROM libro WHERE codigo_identificacion = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, codigo);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Libro(
                        rs.getString("codigo_identificacion"),
                        rs.getString("titulo"),
                        rs.getInt("numero_paginas"),
                        rs.getString("editorial"),
                        rs.getString("ISBN"),
                        rs.getInt("anio_publicacion"),
                        rs.getInt("unidades_disponibles"),
                        rs.getInt("id_autor")
                    );
                }
            }
        }
        return null;
    }
}
